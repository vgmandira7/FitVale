<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fitvale"; // O nome do seu banco de dados

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verifica se o método é POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebe os dados enviados pelo aplicativo
    $nomeTreino = $_POST['nome_treino'];
    $grupoMuscular = $_POST['grupo_muscular'];
    $codAluno = $_POST['aluno_id']; // Recebe o CodAluno
    $codInstrutor = $_POST['codInstrutor']; // Recebe o CodInstrutor
    $exercicios = json_decode($_POST['exercicios'], true); // Recebe o JSON de exercícios e decodifica para array

    // Verifica se há arquivo de imagem
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
        $photo_name = $_FILES["photo"]["name"];
        $photo_tmp_name = $_FILES["photo"]["tmp_name"];
        $random_name = rand(1000, 1000000) . "-" . $photo_name;

        // Move o arquivo para o diretório desejado
        if (move_uploaded_file($photo_tmp_name, "img/" . $random_name)) {
            $upload_name = "http://192.168.1.73/pam3etim/apireact/img/" . $random_name; // URL da imagem
            $upload_name = preg_replace('/\s+/', '-', $upload_name); // Remove espaços

            // Prepara a query para inserir os dados na tabela `treino`
            $stmt = $conn->prepare("INSERT INTO treino (nome_treino, grupo_muscular, image, image_text, CodAluno, CodInstrutor) VALUES (?, ?, ?, ?, ?, ?)"); // Adiciona CodInstrutor
            $stmt->bind_param("ssssii", $nomeTreino, $grupoMuscular, $photo_name, $upload_name, $codAluno, $codInstrutor); // Bind do CodInstrutor

            // Executa a query para inserir o treino
            if ($stmt->execute()) {
                $treino_id = $stmt->insert_id; // Pega o ID do treino inserido

                // Agora insere cada exercício na tabela `exercicio_treino`
                foreach ($exercicios as $exercicio) {
                    $CodExercicio = $exercicio['CodExercicios'];
                    $Nome = $exercicio['Nome'];
                    $series = $exercicio['series'];
                    $repeticoes = $exercicio['repeticoes'];
                    $carga = $exercicio['carga'];

                    // Prepara a query para inserir cada exercício
                    $stmtExercicio = $conn->prepare("INSERT INTO exercicio_treino (treino_id, CodExercicio, Nome, series, repeticoes, carga) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmtExercicio->bind_param("iisiii", $treino_id, $CodExercicio, $Nome, $series, $repeticoes, $carga);

                    // Executa a query
                    if (!$stmtExercicio->execute()) {
                        echo json_encode(["status" => "error", "message" => "Erro ao salvar exercício."]);
                        exit;
                    }
                }

                echo json_encode(["status" => "success", "message" => "Treino e imagem salvos com sucesso!"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao salvar treino."]);
            }

            // Fecha o statement
            $stmt->close();
        } else {
            echo json_encode(["status" => "error", "message" => "Erro ao mover a imagem."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Nenhuma imagem foi enviada."]);
    }

    // Fecha a conexão
    $conn->close();
}
?>
