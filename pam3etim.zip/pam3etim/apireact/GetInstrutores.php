<?php
include 'conexao.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Busca apenas usuários que são instrutores
$sql = "SELECT CodAluno, Nome, Email, Imagem FROM aluno WHERE TipoUsuario = 'instrutor'";
$result = $conn->query($sql);

$instrutores = array();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        // Se tiver imagem salva no banco
        if (!empty($row['Imagem'])) {
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/' . $row['Imagem'];
        } else {
            // Imagem padrão
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/img/perfilPadrao.png';
        }

        $instrutores[] = $row;
    }
}

// Retorna JSON
echo json_encode($instrutores);

$conn->close();
?>