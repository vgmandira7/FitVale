<?php
header('Content-Type: application/json');

// Configurações de conexão com o banco de dados
$host = 'localhost';
$db = 'fitvale';
$user = 'root';
$pass = '';

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    // Conexão com o banco de dados
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o parâmetro userId foi enviado na requisição
    if (isset($_GET['userId']) && filter_var($_GET['userId'], FILTER_VALIDATE_INT)) {
        $userId = (int)$_GET['userId']; // Captura o userId como inteiro
        
        // Consulta para buscar todos os treinos associados ao aluno, incluindo a imagem
        $sql = "
        SELECT 
            t.nome_treino, 
            t.grupo_muscular, 
            t.CodInstrutor,
            t.image, 
            t.image_text, 
            et.nome AS nome_exercicio, 
            et.series, 
            et.repeticoes, 
            et.carga,
            COUNT(et.id) AS total_exercicios
        FROM 
            treino t 
        JOIN 
            exercicio_treino et ON t.id = et.treino_id 
        WHERE 
            t.CodAluno = :userId 
        GROUP BY 
            t.id, et.nome
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->execute();

        // Verifica se encontrou treinos
        if ($stmt->rowCount() > 0) {
            $treinos = [];

            // Organiza os treinos em um array associando os exercícios e as imagens a cada treino
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $nome_treino = $row['nome_treino'];
                if (!isset($treinos[$nome_treino])) {
                    $treinos[$nome_treino] = [
                        'nome_treino' => $nome_treino,
                        'grupo_muscular' => $row['grupo_muscular'],
                        'image' => $row['image'], // Adiciona a imagem
                        'image_text' => $row['image_text'], // Adiciona a URL da imagem
                        'total_exercicios' => $row['total_exercicios'], // Total de exercícios
                        'exercicios' => []
                    ];
                }
                
                // Adiciona os exercícios
                $treinos[$nome_treino]['exercicios'][] = [
                    'nome_exercicio' => $row['nome_exercicio'],
                    'series' => $row['series'],
                    'repeticoes' => $row['repeticoes'],
                    'carga' => $row['carga'],
                    'imagem' => !empty($row['image']) ? $row['image'] : 'https://via.placeholder.com/150?text=No+Image' // Imagem padrão
                ];
            }

            echo json_encode([
                'success' => true,
                'treinos' => array_values($treinos) // Converte o array associativo em um array indexado
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Nenhum treino encontrado.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Parâmetro userId inválido ou ausente.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $e->getMessage()]);
}
