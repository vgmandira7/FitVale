<?php
// Conexão existente com o banco de dados (utilizando mysqli)
$servername = "localhost"; // ou o IP do servidor
$username = "root"; // nome de usuário do banco de dados
$password = ""; // senha do banco de dados
$dbname = "fitvale"; // nome do banco de dados

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Falha na conexão: ' . $conn->connect_error]));
}

// Receber os dados JSON enviados
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Verificar se todos os campos necessários estão presentes
if (isset($data['altura'], $data['peso'], $data['objetivos'], $data['diasTreino'], $data['experiencia'], $data['preferencia'], $data['restricoes'], $data['habitos'], $data['nivelCondicionamento'], $data['comentarios'])) {

    // Extrair os dados do JSON
    $altura = $data['altura'];
    $peso = $data['peso'];
    $objetivos = $data['objetivos'];
    $diasTreino = $data['diasTreino'];
    $experiencia = $data['experiencia'];
    $preferencia = $data['preferencia'];
    $restricoes = $data['restricoes'];
    $habitos = $data['habitos'];
    $nivelCondicionamento = $data['nivelCondicionamento'];
    $comentarios = $data['comentarios'];

    // Preparar a query SQL para inserir os dados no banco de dados
    $sql = "INSERT INTO ficha_tecnica (altura, peso, objetivos, diasTreino, experiencia, preferencia, restricoes, habitos, nivelCondicionamento, comentarios) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Preparar a declaração SQL
    if ($stmt = $conn->prepare($sql)) {

        // Vincular os parâmetros
        $stmt->bind_param("ssssssssss", $altura, $peso, $objetivos, $diasTreino, $experiencia, $preferencia, $restricoes, $habitos, $nivelCondicionamento, $comentarios);

        // Executar a query
        if ($stmt->execute()) {
            // Retornar uma resposta de sucesso
            echo json_encode(['success' => true, 'message' => 'Dados inseridos com sucesso!']);
        } else {
            // Retornar uma mensagem de erro se a execução falhar
            echo json_encode(['success' => false, 'message' => 'Erro ao inserir os dados: ' . $stmt->error]);
        }

        // Fechar a declaração
        $stmt->close();
    } else {
        // Retornar mensagem de erro caso haja um problema na preparação da query
        echo json_encode(['success' => false, 'message' => 'Erro na preparação da query: ' . $conn->error]);
    }
} else {
    // Se algum campo estiver ausente, retornar erro
    echo json_encode(['success' => false, 'message' => 'Todos os campos são obrigatórios.']);
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
