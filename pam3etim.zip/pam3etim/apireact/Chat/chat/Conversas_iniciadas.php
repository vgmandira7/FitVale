<?php 
include_once('../conexao.php');

header("Access-Control-Allow-Origin: *"); // Permite acessos de outros domínios (CORS)
header("Content-Type: application/json; charset=UTF-8"); // Define o tipo de conteúdo como JSON

// Verifica se o parâmetro 'ids' foi enviado na URL
if (isset($_GET['ids']) && !empty($_GET['ids'])) {
    $ids = explode(',', $_GET['ids']);
    error_log('IDs recebidos: ' . print_r($ids, true)); // Loga os IDs recebidos.

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $query = $pdo->prepare("SELECT Nome, Imagem FROM aluno WHERE CodAluno IN ($placeholders)");

    if ($query->execute($ids)) {
        $res = $query->fetchAll(PDO::FETCH_ASSOC);

        if (count($res) > 0) {
            foreach ($res as &$row) {
                // Verifica se o campo 'Imagem' está preenchido e monta a URL completa
                if (!empty($row['Imagem'])) {
                    $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/' . $row['Imagem']; // Substitua pelo domínio do seu servidor
                } else {
                    // Define uma imagem padrão caso o campo esteja vazio
                    $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/img/perfilVitor.png';
                }
            }

            echo json_encode(['success' => true, 'result' => $res]);
        } else {
            echo json_encode(['success' => false, 'result' => 'Nenhum aluno encontrado.']);
        }
    } else {
        error_log('Erro na execução da consulta: ' . print_r($query->errorInfo(), true)); // Loga erros da consulta.
        echo json_encode(['success' => false, 'result' => 'Erro na consulta SQL.']);
    }
} else {
    error_log('IDs inválidos ou não fornecidos.');
    echo json_encode(['success' => false, 'result' => 'IDs inválidos ou não fornecidos.']);
}
