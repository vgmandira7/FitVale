<?php
require_once("../conexao.php");

$postjson = json_decode(file_get_contents('php://input'), true);


//ver esses dois depois
$idUser = @$postjson['userID'];
$idGuia = @$postjson['guiaID'];
$channelName = @$postjson['channelName'];

// Verificar se os dados foram recebidos corretamente
error_log("ID do usuário: " . $idUser);
error_log("ID do guia: " . $idGuia);
error_log("Nome do canal: " . $channelName);


try {
    $res = $pdo->prepare("INSERT INTO canais_chat (id_personal, id_usuario, nome_canal) VALUES (:id_personal, :id_usuario, :nome_canal)");
    $res->bindValue(":id_personal", $idGuia);
    $res->bindValue(":id_usuario", $idUser);
    $res->bindValue(":nome_canal", $channelName);

    $res->execute();
    $result = json_encode(array('mensagem' => 'Salvo com sucesso!', 'success' => true));
    echo $result;

} catch (PDOException $e) {
    $result = json_encode(array('mensagem' => 'Erro ao salvar: ' . $e->getMessage(), 'success' => false));
    echo $result;
}
?>