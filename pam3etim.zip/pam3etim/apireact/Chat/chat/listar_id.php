<?php

include_once('../conexao.php');

// Verifica se o parâmetro 'id' foi enviado na URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id']; // Pega o valor do ID e já sabe que é numérico

    $dados = [];

    // Primeiro, verifica se há correspondência em id_usuario
    $query1 = $pdo->prepare("SELECT cc.id_personal FROM canais_chat cc WHERE cc.id_usuario = :id");
    $query1->bindValue(':id', $id, PDO::PARAM_INT);
    $query1->execute();
    $res1 = $query1->fetchAll(PDO::FETCH_ASSOC);

    if (count($res1) > 0) {
        // Se encontrar correspondência, retorna o id_personal
        foreach ($res1 as $row) {
            $dados[] = array(
                'idPersonal' => $row['id_personal']
            );
        }

        echo json_encode(array('success' => true, 'result' => $dados));
        exit; // Finaliza o script porque já encontramos o resultado
    }

    // Se não encontrar em id_usuario, verifica em id_personal
    $query2 = $pdo->prepare("SELECT cc.id_usuario FROM canais_chat cc WHERE cc.id_personal = :id");
    $query2->bindValue(':id', $id, PDO::PARAM_INT);
    $query2->execute();
    $res2 = $query2->fetchAll(PDO::FETCH_ASSOC);

    if (count($res2) > 0) {
        // Se encontrar correspondência, retorna o id_usuario
        foreach ($res2 as $row) {
            $dados[] = array(
                'idUsuario' => $row['id_usuario']
            );
        }

        echo json_encode(array('success' => true, 'result' => $dados));
    } else {
        // Caso não encontre nenhum resultado em nenhuma das consultas
        echo json_encode(array('success' => false, 'result' => 'Nenhum dado encontrado.'));
    }
} else {
    // Caso o parâmetro 'id' não seja válido ou não exista
    echo json_encode(array('success' => false, 'result' => 'ID inválido ou não fornecido.'));
}
