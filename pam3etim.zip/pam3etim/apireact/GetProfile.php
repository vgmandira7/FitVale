<?php
include 'conexao.php';  // Inclua o arquivo de conexão com o banco de dados

// Recebe o ID do usuário enviado via POST
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

// Verifica se o ID do usuário é válido
if ($user_id > 0) {
    // Consulta SQL para obter as informações do usuário
    $sql = "SELECT Nome, Email, Imagem FROM aluno WHERE CodAluno = '$user_id'";
    $result = mysqli_query($conn, $sql);

    if ($result && $result->num_rows > 0) {
        $row = mysqli_fetch_assoc($result);
        
        // Verifica e ajusta o caminho da imagem
        if (!empty($row['Imagem'])) {
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/' . $row['Imagem']; // Substitua pelo domínio correto
        } else {
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/img/perfilVitor.png'; // Imagem padrão
        }

        echo json_encode($row);  // Retorna os dados em formato JSON
    } else {
        echo json_encode(["error" => "Usuário não encontrado."]);
    }
} else {
    echo json_encode(["error" => "ID do usuário inválido."]);
}

mysqli_close($conn);  // Fecha a conexão com o banco de dados
?>
