<?php
header('Content-Type: application/json');

// Conexão com o banco de dados
$conn = new mysqli("localhost", "usuario", "senha", "nome_do_banco");

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Falha na conexão com o banco de dados."]));
}

// Capturando os dados do formulário
$data = json_decode(file_get_contents('php://input'), true);

$altura = $data['altura'];
$peso = $data['peso'];
$objetivos = $data['objetivos'];
$diasTreino = $data['diasTreino'];
$experiencia = $data['experiencia'];

// Inserindo os dados iniciais
$sql = "INSERT INTO ficha_tecnica (altura, peso, objetivos, diasTreino, experiencia) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $altura, $peso, $objetivos, $diasTreino, $experiencia);

if ($stmt->execute()) {
    $id = $conn->insert_id; // Obtém o ID gerado
    echo json_encode(["success" => true, "id" => $id]);
} else {
    echo json_encode(["success" => false, "message" => "Erro ao inserir os dados."]);
}

$conn->close();
?>
