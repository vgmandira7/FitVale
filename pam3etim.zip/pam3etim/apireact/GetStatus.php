<?php
header('Content-Type: application/json');
include 'conexao.php'; // Inclua seu arquivo de conexão

// Verifique se o parâmetro aluno_id foi passado
if (!isset($_GET['aluno_id'])) {
    echo json_encode(['error' => 'Parâmetro aluno_id não fornecido']);
    exit();
}

// Supondo que você está passando um ID de aluno como parâmetro
$aluno_id = $_GET['aluno_id'];

// Verifique se o parâmetro é um número válido
if (!filter_var($aluno_id, FILTER_VALIDATE_INT)) {
    echo json_encode(['error' => 'ID de aluno inválido']);
    exit();
}

$query = "SELECT Status, PagamentoData FROM aluno WHERE CodAluno = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    echo json_encode(['error' => 'Erro na preparação da consulta']);
    exit();
}

$stmt->bind_param("i", $aluno_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode($row);
} else {
    echo json_encode(['Status' => 'pendente', 'PagamentoData' => null]);
}

$stmt->close();
$conn->close();
?>
