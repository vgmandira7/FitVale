<?php
$servername = "localhost"; // ou o IP do servidor
$username = "root"; // nome de usuário do banco de dados
$password = ""; // senha do banco de dados
$dbname = "fitvale"; // nome do banco de dados

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Falha na conexão: ' . $conn->connect_error]));
}

// Consulta para obter as solicitações
$sql = "SELECT aluno.CodAluno, aluno.Nome, aluno.Imagem, ficha_tecnica.data_emissao 
        FROM ficha_tecnica 
        INNER JOIN aluno ON ficha_tecnica.aluno_id = aluno.CodAluno"; // Assumindo que a ficha_tecnica tem um campo aluno_id

$result = $conn->query($sql);
$solicitacoes = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Verifica se o campo 'Imagem' está preenchido e monta a URL completa
        if (!empty($row['Imagem'])) {
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/' . $row['Imagem']; // Substitua pelo domínio do seu servidor
        } else {
            // Define uma imagem padrão caso o campo esteja vazio
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/img/perfilVitor.png';
        }

        $solicitacoes[] = $row; // Adiciona cada solicitação ao array
    }
}

// Retorna os dados em formato JSON
echo json_encode(['success' => true, 'solicitacoes' => $solicitacoes]);

// Fechar a conexão
$conn->close();
?>
