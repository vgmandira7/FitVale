<?php
header('Content-Type: application/json');

include 'conexao.php'; // Inclua a conexão com o banco de dados

// Consulta para verificar se o TipoUsuario é "instrutor"
$sql = "SELECT Nome, Email FROM aluno WHERE TipoUsuario = 'instrutor'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Criar um array para armazenar os dados
    $data = array();
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    // Retornar os dados em formato JSON
    echo json_encode($data);
} else {
    echo json_encode([]);
}

$conn->close();
?>
