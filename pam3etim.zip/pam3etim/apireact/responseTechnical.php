<?php
// conexão com o banco de dados
$host = 'localhost';
$dbname = 'fitvale';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $aluno_id = $_GET['aluno_id']; // Supondo que você passe o ID do usuário via GET

    // Query para pegar as respostas
    $stmt = $pdo->prepare("SELECT altura, peso, objetivos, diasTreino, experiencia, preferencia, restricoes, habitos, nivelCondicionamento, Comentarios FROM ficha_tecnica WHERE aluno_id = :aluno_id");
    $stmt->bindParam(':aluno_id', $aluno_id);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode($result);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
