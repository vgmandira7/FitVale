<?php
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['feedback']) && isset($_POST['estrelas'])) {
        $feedback = $_POST['feedback'];
        $estrelas = $_POST['estrelas'];

        // Prepara a consulta SQL com placeholders
        $stmt = $conn->prepare("INSERT INTO feedback (Mensagem, Estrelas) VALUES (?, ?)");

        if (!$stmt) {
            die("Erro na preparação da consulta: " . $conn->error);
        }

        // Substitui os ? pelos valores de $feedback e $estrelas
        $stmt->bind_param("si", $feedback, $estrelas);

        // Executa a consulta
        if ($stmt->execute()) {
            echo "Feedback enviado com sucesso!";
        } else {
            echo "Erro ao enviar o feedback: " . $stmt->error;
        }

        // Fecha a declaração
        $stmt->close();
    } else {
        echo "Feedback ou estrelas não recebidos.";
    }
} else {
    echo "Método de requisição inválido.";
}

// Fecha a conexão
$conn->close();
?>
