<?php
include_once('conexao.php');

// Recebe os dados JSON da requisição
$postjson = json_decode(file_get_contents("php://input"), true);

// Prepara a consulta SQL
$query = $conn->prepare("SELECT CodAluno, Nome, Email, TipoUsuario, Imagem, StatusPagamento FROM aluno WHERE Email = ? AND Senha = ?");
$query->bind_param("ss", $postjson['email'], $postjson['senha']);
$query->execute();

$result = $query->get_result();
$dados = $result->fetch_all(MYSQLI_ASSOC);

if (count($dados) == 0) {
    $result = json_encode(array('success' => false, 'message' => 'Dados Incorretos!'));
} else {
    // Pega os dados do primeiro registro encontrado
    $dados_usuario = $dados[0];
    $tipo_usuario = $dados_usuario['TipoUsuario'];
    $imagem_perfil = $dados_usuario['Imagem'];
    $cod_aluno = $dados_usuario['CodAluno']; // Adiciona o ID do aluno
    $StatusPagamento = $dados_usuario['StatusPagamento'];

    // Verifica e ajusta o caminho da imagem
    if (!empty($imagem_perfil)) {
        $imagem_perfil = 'http://192.168.1.73/pam3etim/apireact/' . $imagem_perfil; // Substitua pelo domínio correto
    } else {
        $imagem_perfil = 'http://192.168.1.73/pam3etim/apireact/img/perfilVitor.png'; // Imagem padrão
    }

    $result = json_encode(array(
        'success' => true,
        'tipo_usuario' => $tipo_usuario,
        'imagem_perfil' => $imagem_perfil,
        'cod_aluno' => $cod_aluno, // Adiciona o ID do aluno na resposta
        'status_pagamento' => $StatusPagamento

    ));
}

echo $result;

?>
