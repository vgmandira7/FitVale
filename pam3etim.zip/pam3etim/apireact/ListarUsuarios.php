<?php
include 'conexao.php'; // Inclui o arquivo de conexão

header("Access-Control-Allow-Origin: *"); // Permite acessos de outros domínios (CORS)
header("Content-Type: application/json; charset=UTF-8"); // Define o tipo de conteúdo como JSON

// Consulta para selecionar os instrutores
$sql = "SELECT CodAluno, Nome, Email, Imagem, DataNasc FROM aluno WHERE TipoUsuario = 'instrutor';"; 
$result = $conn->query($sql);

$instrutores = array(); // Array para armazenar os instrutores

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Verifica se o campo 'Imagem' está preenchido e monta a URL completa
        if (!empty($row['Imagem'])) {
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/' . $row['Imagem']; // Substitua pelo domínio do seu servidor
        } else {
            // Define uma imagem padrão caso o campo esteja vazio
            $row['Imagem'] = 'http://192.168.1.73/pam3etim/apireact/img/perfilVitor.png';
        }

        $instrutores[] = $row; // Adiciona cada instrutor ao array
    }
}

// Retorna os dados em formato JSON
echo json_encode($instrutores);

$conn->close(); // Fecha a conexão com o banco de dados
?>
