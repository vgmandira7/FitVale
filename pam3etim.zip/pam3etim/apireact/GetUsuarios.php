<?php
// Inclua o arquivo de conexão
include_once 'conexao.php';

try {
    // Consulta para selecionar todos os usuários
    $sql = "SELECT CodAluno, Nome FROM aluno";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Cria um array para armazenar os dados
    $usuarios = array();

    // Fetch dos resultados
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $usuarios[] = array(
            'CodAluno' => $row['CodAluno'],
            'Nome' => $row['Nome'],
        );
    }

    // Retorna os dados em formato JSON
    echo json_encode($usuarios);
    
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
