<?php
include 'conexao.php'; // Inclui o arquivo de conexão

header("Access-Control-Allow-Origin: *"); // Permite acessos de outros domínios (CORS)
header("Content-Type: application/json; charset=UTF-8"); // Define o tipo de conteúdo como JSON

$sql = "SELECT * FROM exercicios"; // Consulta para buscar os exercícios
$result = $conn->query($sql);

$exercicios = array(); // Array para armazenar os exercícios

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $exercicios[] = $row; // Adiciona cada exercício ao array
    }
    echo json_encode(array("exercicios" => $exercicios)); // Retorna os dados em formato JSON
} else {
    echo json_encode(array("mensagem" => "Nenhum exercício encontrado")); // Caso não encontre nenhum exercício
}

$conn->close(); // Fecha a conexão com o banco de dados
?>
