<?php
include 'conexao.php';  // Inclua sua conexão com o banco de dados

// Recebe o ID do usuário da URL
$userId = isset($_GET['userId']) ? intval($_GET['userId']) : 1;

// Define o tipo de conteúdo como JSON
header('Content-Type: application/json');

// Query para buscar os dados de pagamento do usuário específico
$query = "SELECT CodAluno, StatusPagamento, PagamentoData FROM aluno WHERE CodAluno = $userId";
$result = mysqli_query($conn, $query);

$alunosAtualizados = [];  // Array para armazenar os alunos atualizados

while ($row = mysqli_fetch_assoc($result)) {
    $CodAluno = $row['CodAluno'];
    $Status = $row['StatusPagamento'];
    $PagamentoData = new DateTime($row['PagamentoData']);
    $dataAtual = new DateTime();

    // Calcula a diferença em dias entre a data atual e a data do pagamento
    $diferenca = $dataAtual->diff($PagamentoData)->days;

    if ($Status == 'pago' && $diferenca > 30 && $diferenca <= 60) {
        // Se passou mais de 30 dias, mas menos de 60, o status é "pendente"
        $novoStatus = 'pendente';
    } elseif ($Status == 'pendente' && $diferenca > 60) {
        // Se passou mais de 60 dias, o status é "vencido"
        $novoStatus = 'vencido';
    } elseif ($Status == "pendente" && $diferenca > 30 && $diferenca <= 60){
        // Se o pagamento foi feito nos últimos 30 dias, mantém como 'pago'
        $novoStatus = "pendente";
    } elseif($Status == "vencido" && $diferenca > 60){
        $novoStatus = "vencido";
    } else{
        $novoStatus = "pago";
    }

    // Atualiza o status no banco de dados
    $updateQuery = "UPDATE aluno SET StatusPagamento = '$novoStatus' WHERE CodAluno = $CodAluno";
    if (mysqli_query($conn, $updateQuery)) {
        // Log para monitorar atualizações
        error_log("Status do aluno $CodAluno atualizado para: $novoStatus");
    } else {
        // Log de erro
        error_log("Erro ao atualizar status do aluno $CodAluno: " . mysqli_error($conn));
    }

    // Adiciona o aluno atualizado ao array
    $alunosAtualizados[] = [
        'CodAluno' => $CodAluno,
        'StatusPagamento' => $novoStatus,
        'PagamentoData' => $row['PagamentoData'],
        "Diferenca" => $diferenca
    ];
}

//
echo json_encode($alunosAtualizados);